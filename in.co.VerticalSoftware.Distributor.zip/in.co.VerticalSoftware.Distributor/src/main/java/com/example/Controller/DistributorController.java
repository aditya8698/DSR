package com.example.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.Entity.Distributor;
import com.example.Service.DistService;

@Controller
public class DistributorController {

	@Autowired
	DistService distservice;

	@GetMapping("/Home")
	public String gethome() {
		return "Distributor";
	}
	
	
	@PostMapping("/Distributors")
	public String getdata(Model model, @ModelAttribute("Distributor") Distributor dist) {
		List<Distributor> ls = new ArrayList<Distributor>();
		ls.addAll(distservice.insertdata(dist));
		model.addAttribute("Alldata", ls);
		System.out.println("*********" + ls + "***********");
		return "Distributor";
	}
	
	@GetMapping("/Delete")
	public String deletedata(@RequestParam("id") Integer id,
			Model model) {
		List<Distributor> ls = new ArrayList<Distributor>();
		ls.addAll(distservice.deletedata(id));
		model.addAttribute("Alldata", ls);
		return "Distributor";
	}
	
	@GetMapping("/Update")
	public String updatedata(@RequestParam("id") Integer id,
			Model model) {
		Distributor dis = distservice.updatedata(id);
		dis.setId(id);
		model.addAttribute("Alldata1", dis);
		System.out.println("*******"+dis);
		return "DistUpdate";
	}
	
}
