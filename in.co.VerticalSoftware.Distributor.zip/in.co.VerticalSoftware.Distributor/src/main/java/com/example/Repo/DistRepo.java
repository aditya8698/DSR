package com.example.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Entity.Distributor;

@Repository
public interface DistRepo extends JpaRepository<Distributor, Integer> {

}
