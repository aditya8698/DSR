package com.example.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.Entity.Distributor;
import com.example.Repo.DistRepo;

@Component
@Service
public class DistService implements DisttributorService {

	@Autowired
	private DistRepo disrepo;
	
	

	@Override
	public List<Distributor> insertdata(Distributor dist) {
        
		disrepo.save(dist);
		List<Distributor> list = disrepo.findAll();
        return list;
	}



	public List<Distributor> deletedata(Integer id) {
		// TODO Auto-generated method stub
		disrepo.deleteById(id);
		List<Distributor> list = disrepo.findAll();
		return list;
		
		
	}

    public Distributor updatedata(Integer id) {
		return disrepo.getById(id);
		
	}

}
