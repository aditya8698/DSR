package com.example.Service;

import java.util.List;

import com.example.Entity.Distributor;

public interface DisttributorService {
	
	public List<Distributor> insertdata(Distributor dist);

}
