package com.example.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Component
@Table
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Distributor {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;
	@Column
	private String name;
	@Column
	private String pan;
	@Column
	private String address;
	@Column
	private String city;
	@Column
	private String state;
	@Column
	private long zipcode;
	@Column
	private long phone;
	@Column
	private String email;
	
	

}
